"""
End-to-end tests for the Level app. Runs the real app in headless Chromium at
iPhone size, Rome timezone, with a controllable clock.

    pip install playwright && python -m playwright install chromium
    python test_app.py

Serves the current folder on localhost:8765 for the duration of the run and
writes screenshots to ./shots/. Exit code 1 on any failure.
"""
import json, datetime, sys, os, subprocess, time, pathlib
from zoneinfo import ZoneInfo
ROME = ZoneInfo("Europe/Rome")
from playwright.sync_api import sync_playwright

HERE = pathlib.Path(__file__).resolve().parent
os.chdir(HERE)
pathlib.Path("shots").mkdir(exist_ok=True)
server = subprocess.Popen([sys.executable, "-m", "http.server", "8765", "--bind", "127.0.0.1"],
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1.0)
URL = "http://localhost:8765/index.html"
IPHONE = dict(viewport={"width": 390, "height": 844}, device_scale_factor=2,
              is_mobile=True, has_touch=True, timezone_id="Europe/Rome", locale="en-GB")
fails = []
def check(name, cond, extra=""):
    print(("PASS " if cond else "FAIL ") + name + (("  -> " + str(extra)) if (extra and not cond) else ""))
    if not cond: fails.append(name)

with sync_playwright() as p:
    browser = p.chromium.launch()

    # ---------- 1. fresh install, fixed clock: Mon 7 Sep 2026 23:30 Rome ----------
    ctx = browser.new_context(**IPHONE)
    page = ctx.new_page()
    errors = []
    page.on("pageerror", lambda e: errors.append(str(e)))
    page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    page.clock.install(time=datetime.datetime(2026, 9, 7, 23, 30, 0, tzinfo=ROME))
    page.on("dialog", lambda dlg: dlg.accept())
    page.goto(URL)
    page.wait_for_selector(".hero")
    check("no JS errors on load", not errors, errors)
    check("header shows local date", "Monday 7 September" in page.inner_text("#today"), page.inner_text("#today"))
    check("starts at level 1 / 0 XP", "Level 1" in page.inner_text(".lvl") and page.inner_text(".total").strip() == "0")
    check("three seeded sections plus the weight section on home", page.locator("h2 .dot").count() == 4)
    page.screenshot(path="shots/home_empty.png", full_page=True)

    # log the gym (multi) twice, steps (daily) once, then toggle steps off
    gym = page.locator(".row[data-act=log]", has_text="Gym session")
    gym.click(); page.wait_for_timeout(50)
    gym.click(); page.wait_for_timeout(50)
    steps = page.locator(".row[data-act=log]", has_text="8k steps")
    steps.click(); page.wait_for_timeout(50)
    check("multi habit logs twice, daily once", page.inner_text(".total").strip() == "120", page.inner_text(".total"))
    check("level 2 reached at 120 XP", "Level 2" in page.inner_text(".lvl"))
    check("gym row shows 2x today", "2× today" in page.locator(".row[data-act=log]", has_text="Gym session").inner_text())
    steps.click(); page.wait_for_timeout(50)
    check("daily habit toggles off", page.inner_text(".total").strip() == "100")
    check("fitness section shows today XP", "100 XP today" in page.locator("h2", has_text="Fitness").inner_text())
    check("streak is 1", "1 day streak" in page.inner_text(".streak"))

    # ---------- daily goals on home ----------
    badge_calls = []
    page.evaluate("""() => { window.__badge=[]; navigator.setAppBadge = n => { window.__badge.push(n); return Promise.resolve(); };
                            navigator.clearAppBadge = () => { window.__badge.push(0); return Promise.resolve(); }; }""")
    check("pending count shown (4 daily habits left)", "4 left" in page.inner_text(".pendline"), page.inner_text(".pendline"))
    check("21:00 reminder banner shows at 23:30 with pending items", "21:00 reminder" in page.inner_text("#view") and "4 still to do" in page.inner_text("#view"))
    page.locator("button[data-act=task-form]").click(); page.wait_for_timeout(50)
    check("quick-add form opens and focuses name", page.evaluate("document.activeElement && document.activeElement.id") == "f-t-name")
    page.locator("button[data-act=task-add]").click(); page.wait_for_timeout(50)
    check("empty goal rejected", page.locator(".row.task").count() == 0)
    page.fill("#f-t-name", "Finish marketing homework"); page.fill("#f-t-xp", "40")
    page.select_option("#f-t-cat", label="School")
    page.keyboard.press("Enter"); page.wait_for_timeout(50)
    check("Enter adds the goal and form stays open", page.locator(".row.task", has_text="Finish marketing homework").count() == 1 and page.locator("#f-t-name").count() == 1)
    check("name field cleared for the next goal", page.input_value("#f-t-name") == "")
    check("section remembered from last goal", page.evaluate("document.getElementById('f-t-cat').selectedOptions[0].text") == "School")
    page.fill("#f-t-name", "Email tutor"); page.fill("#f-t-xp", "15")
    page.locator("button[data-act=task-add]").click(); page.wait_for_timeout(50)
    check("two goals, 0/2 done, 6 left", "0/2 done" in page.locator(".goals-head").inner_text() and "6 left" in page.inner_text(".pendline"))
    page.locator(".row.task[data-act=task]", has_text="Email tutor").click(); page.wait_for_timeout(50)
    check("completing a goal adds its XP", page.inner_text(".total").strip() == "115" and "1/2 done" in page.locator(".goals-head").inner_text())
    check("School section counts goal XP today", "15 XP today" in page.locator("h2", has_text="School").inner_text())
    page.locator(".row.task", has_text="Email tutor").click(); page.wait_for_timeout(50)
    check("tap again reopens the goal", page.inner_text(".total").strip() == "100")
    page.locator(".row.task", has_text="Email tutor").click(); page.wait_for_timeout(50)
    page.locator(".row.task", has_text="Email tutor").locator("button[data-act=task-del]").click(); page.wait_for_timeout(80)
    check("deleting a done goal removes its XP", page.inner_text(".total").strip() == "100" and page.locator(".row.task", has_text="Email tutor").count() == 0)
    calls = page.evaluate("window.__badge")
    check("app badge updated with pending count", calls and calls[-1] == 5, calls)

    # complete an objective, then reopen it
    obj = page.locator(".row[data-act=goal]", has_text="Bench press")
    obj.click(); page.wait_for_timeout(50)
    check("objective adds XP", page.inner_text(".total").strip() == "400")
    check("objective moves out of open list", page.locator(".row[data-act=goal]", has_text="Bench press").count() == 0)
    check("section notes done count", "1 done" in page.locator("h3", has_text="Objectives").first.inner_text())
    page.locator("button[data-act=undo]").click(); page.wait_for_timeout(50)
    check("undo reopens objective and removes XP", page.inner_text(".total").strip() == "100"
          and page.locator(".row[data-act=goal]", has_text="Bench press").count() == 1)

    # ---------- persistence across reload ----------
    page.reload(); page.wait_for_selector(".hero")
    check("data survives reload", page.inner_text(".total").strip() == "100")
    raw = page.evaluate("localStorage.getItem('level.v2')")
    d = json.loads(raw)
    check("stored dates are local calendar days (23:30 Rome stays 7 Sep)", all(e["date"] == "2026-09-07" for e in d["log"]), [e["date"] for e in d["log"]])
    check("start date anchored to first launch", d["start"] == "2026-09-07")

    # ---------- midnight rollover while app open ----------
    page.clock.run_for(45 * 60 * 1000)   # 23:30 -> 00:15 Tue 8 Sep
    page.evaluate("document.dispatchEvent(new Event('visibilitychange'))")
    page.wait_for_timeout(100)
    check("header rolls over to Tuesday 8 September", "Tuesday 8 September" in page.inner_text("#today"), page.inner_text("#today"))
    check("gym resets to 0x today after midnight", "Tap each time" in page.locator(".row[data-act=log]", has_text="Gym session").inner_text())
    check("streak still 1 (yesterday counts)", "1 day streak" in page.inner_text(".streak"))
    check("total XP unchanged after rollover", page.inner_text(".total").strip() == "100")
    check("unfinished goal from yesterday shown as overdue", "Unfinished from earlier" in page.inner_text("#view") and "Set for 7 Sept" in page.locator(".row.task", has_text="Finish marketing homework").inner_text())
    page.locator("button[data-act=task-move]").click(); page.wait_for_timeout(50)
    check("move to today", "Unfinished from earlier" not in page.inner_text("#view") and "0/1 done" in page.locator(".goals-head").inner_text())
    check("no reminder banner at 00:15 before first time", "reminder." not in page.inner_text("#view"))

    # ---------- calendar ----------
    page.locator("button[data-act=tab][data-id=calendar]").click()
    page.wait_for_selector(".cal")
    check("calendar shows September 2026", "September 2026" in page.inner_text(".calhead"))
    first_cells = page.locator(".cal .day").all()
    # Sept 1 2026 is a Tuesday -> exactly 1 blank before it
    check("Monday-first alignment (1 blank before Tue 1 Sep)", "blank" in first_cells[0].get_attribute("class") and first_cells[1].inner_text().startswith("1"))
    check("7 Sep coloured with 100 XP", page.locator(".day[data-act=pick][data-id='2026-09-07']").get_attribute("data-l") == "3")
    check("8 Sep is today", "today" in page.locator(".day[data-id='2026-09-08']").get_attribute("class"))
    page.locator(".day[data-act=pick][data-id='2026-09-09']").click(); page.wait_for_timeout(50)
    check("future day opens a planning panel with no habit logging", page.locator("#f-t-name").count() == 1 and page.locator("#f-cal-habit").count() == 0 and "Nothing planned" in page.inner_text("#view"))
    page.fill("#f-t-name", "Submit essay draft"); page.fill("#f-t-xp", "60")
    page.locator("button[data-act=task-add]").click(); page.wait_for_timeout(50)
    check("goal planned on a future day", page.locator(".row.task", has_text="Submit essay draft").count() == 1)
    check("future planned goal is not tappable", page.locator(".row.task[data-act=task]", has_text="Submit essay draft").count() == 0)
    check("calendar cell shows planned count", "1 planned" in page.locator(".day[data-id='2026-09-09']").inner_text())
    check("month stats", "100" in page.locator(".stat").nth(0).inner_text() and "1" in page.locator(".stat").nth(1).inner_text())

    # backfill: pick yesterday, log Read 20 minutes
    page.locator(".day[data-act=pick][data-id='2026-09-07']").click()
    page.wait_for_selector("#f-cal-habit")
    check("day panel shows 7 Sep entries", page.locator(".entry").count() == 2)
    page.select_option("#f-cal-habit", label="Read 20 minutes (+10)")
    page.locator("button[data-act=log-day]").click(); page.wait_for_timeout(50)
    check("backfilled entry lands on 7 Sep", page.locator(".entry").count() == 3 and "110 XP" in page.locator("h2", has_text="Monday 7 September").inner_text())
    check("past day shows its goals list", "Goals for this day" in page.inner_text("#view"))
    # remove one gym entry from that day
    page.locator(".entry", has_text="Gym session").first.locator("button[data-act=rm-entry]").click(); page.wait_for_timeout(50)
    check("remove entry from a past day", page.locator(".entry").count() == 2)
    # navigate months
    page.locator("button[data-act=cal-prev]").click()
    check("prev month -> August 2026", "August 2026" in page.inner_text(".calhead"))
    for _ in range(6): page.locator("button[data-act=cal-prev]").click()
    check("wraps year backwards -> February 2026", "February 2026" in page.inner_text(".calhead"))
    check("Feb 2026 has 28 day cells", page.locator(".cal .day:not(.blank)").count() == 28)
    for _ in range(11): page.locator("button[data-act=cal-next]").click()
    check("wraps year forwards -> January 2027", "January 2027" in page.inner_text(".calhead"))
    for _ in range(4): page.locator("button[data-act=cal-prev]").click()
    page.screenshot(path="shots/calendar.png", full_page=True)

    # ---------- manage: sections ----------
    page.locator("button[data-act=tab][data-id=manage]").click()
    page.wait_for_selector(".seg")
    page.fill("#f-cat-name", "Career")
    page.locator(".sw[data-id='#F97316']").click()
    page.locator("button[data-act=save-cat]").click(); page.wait_for_timeout(50)
    check("add section", page.locator(".row", has_text="Career").count() == 1)
    page.locator(".row", has_text="Career").locator("button[data-act=edit-cat]").click()
    page.wait_for_timeout(50)
    check("edit form prefilled", page.input_value("#f-cat-name") == "Career" and page.locator(".sw[aria-pressed=true]").get_attribute("data-id") == "#F97316")
    page.fill("#f-cat-name", "Work")
    page.locator("button[data-act=save-cat]").click(); page.wait_for_timeout(50)
    check("rename section", page.locator(".row", has_text="Work").count() == 1 and page.locator(".row", has_text="Career").count() == 0)
    page.locator(".row", has_text="School").locator("button[data-act=del-cat]").click(); page.wait_for_timeout(80)
    check("delete section", page.locator(".row", has_text="School").count() == 0)
    d = json.loads(page.evaluate("localStorage.getItem('level.v2')"))
    orphan = [h for h in d["habits"] if h["cat"] not in {c["id"] for c in d["cats"]}]
    check("deleted section's items reassigned, no orphans", not orphan, orphan)

    # ---------- manage: habits ----------
    page.locator("button[data-act=seg][data-id=habits]").click()
    page.fill("#f-h-name", "Cold shower")
    page.fill("#f-h-xp", "12")
    page.select_option("#f-h-mode", "daily")
    page.select_option("#f-h-cat", label="Work")
    page.locator("button[data-act=save-habit]").click(); page.wait_for_timeout(50)
    check("add habit", page.locator(".row", has_text="Cold shower").count() == 1)
    page.fill("#f-h-name", "Bad")
    page.fill("#f-h-xp", "0")
    page.locator("button[data-act=save-habit]").click(); page.wait_for_timeout(50)
    check("rejects XP of 0", page.locator(".row", has_text="Bad").count() == 0)
    page.evaluate("document.getElementById('f-h-xp').value=''")
    page.locator("button[data-act=save-habit]").click(); page.wait_for_timeout(50)
    check("rejects empty XP", page.locator(".row", has_text="Bad").count() == 0)
    page.fill("#f-h-xp", "-5")
    page.locator("button[data-act=save-habit]").click(); page.wait_for_timeout(50)
    check("rejects negative XP", page.locator(".row", has_text="Bad").count() == 0)
    page.fill("#f-h-xp", "2.5")
    page.locator("button[data-act=save-habit]").click(); page.wait_for_timeout(50)
    check("rejects decimal XP", page.locator(".row", has_text="Bad").count() == 0)
    # edit gym: multi -> daily should collapse the 7 Sep double-log to one
    page.locator(".row", has_text="Gym session").locator("button[data-act=edit-habit]").click(); page.wait_for_timeout(50)
    check("habit edit prefilled", page.input_value("#f-h-name") == "Gym session" and page.input_value("#f-h-xp") == "50")
    page.select_option("#f-h-mode", "daily")
    page.locator("button[data-act=save-habit]").click(); page.wait_for_timeout(50)
    d = json.loads(page.evaluate("localStorage.getItem('level.v2')"))
    gymlogs = [e for e in d["log"] if e["name"] == "Gym session"]
    check("multi->daily collapses duplicate day entries", len(gymlogs) == 1, len(gymlogs))
    page.locator(".row", has_text="Cold shower").locator("button[data-act=del-habit]").click(); page.wait_for_timeout(80)
    check("delete habit", page.locator(".row", has_text="Cold shower").count() == 0)
    page.screenshot(path="shots/manage_habits.png", full_page=True)

    # ---------- manage: objectives ----------
    page.locator("button[data-act=seg][data-id=goals]").click()
    page.fill("#f-g-name", "Get Equita return offer")
    page.fill("#f-g-xp", "500")
    page.select_option("#f-g-cat", label="Work")
    page.locator("button[data-act=save-goal]").click(); page.wait_for_timeout(50)
    check("add objective", page.locator(".row", has_text="Equita").count() == 1)
    page.locator(".row", has_text="Run 10k").locator(".tick").click(); page.wait_for_timeout(50)
    check("complete objective from manage", page.locator("h2", has_text="Completed").count() == 1)
    page.locator(".row", has_text="Run 10k").locator("button[data-act=edit-goal]").click(); page.wait_for_timeout(50)
    page.fill("#f-g-xp", "400")
    page.locator("button[data-act=save-goal]").click(); page.wait_for_timeout(50)
    d = json.loads(page.evaluate("localStorage.getItem('level.v2')"))
    run = [e for e in d["log"] if e["type"] == "goal"]
    check("editing a completed objective's XP updates its log entry", run and run[0]["xp"] == 400, run)
    page.locator(".row", has_text="Run 10k").locator("button[data-act=del-goal]").click(); page.wait_for_timeout(80)
    d = json.loads(page.evaluate("localStorage.getItem('level.v2')"))
    check("deleting a completed objective removes its XP", not [e for e in d["log"] if e["type"] == "goal"])

    # ---------- target & data ----------
    page.locator("button[data-act=seg][data-id=target]").click()
    page.fill("#f-target", "5000")
    page.fill("#f-deadline", "2026-09-01")
    page.locator("button[data-act=save-target]").click(); page.wait_for_timeout(50)
    d = json.loads(page.evaluate("localStorage.getItem('level.v2')"))
    check("rejects deadline before start", d["target"] == 10000)
    page.fill("#f-deadline", "2026-12-31")
    page.locator("button[data-act=save-target]").click(); page.wait_for_timeout(50)
    d = json.loads(page.evaluate("localStorage.getItem('level.v2')"))
    check("saves valid target", d["target"] == 5000)
    check("persistence note shown (not preview warning)", page.locator(".note.warn").count() == 0)
    check("default reminder times listed", [c.inner_text().strip("×").strip() for c in page.locator(".timechip").all()] == ["15:00", "18:00", "21:00"])
    page.locator(".timechip", has_text="18:00").locator("button").click(); page.wait_for_timeout(50)
    check("remove a reminder time", page.locator(".timechip").count() == 2)
    page.fill("#f-rem-time", "12:30")
    page.locator("button[data-act=rem-add]").click(); page.wait_for_timeout(50)
    check("add a reminder time, kept sorted", [c.inner_text().strip("×").strip() for c in page.locator(".timechip").all()] == ["12:30", "15:00", "21:00"])
    page.fill("#f-rem-time", "15:00")
    page.locator("button[data-act=rem-add]").click(); page.wait_for_timeout(50)
    check("duplicate time rejected", page.locator(".timechip").count() == 3)
    check("shortcut steps use the first time", "12:30" in page.locator(".steps").inner_text())
    page.locator("#f-badge").uncheck(); page.wait_for_timeout(50)
    d = json.loads(page.evaluate("localStorage.getItem('level.v2')"))
    check("badge preference persisted off", d["reminders"]["badge"] is False and d["reminders"]["times"] == ["12:30", "15:00", "21:00"])
    page.locator("#f-badge").check(); page.wait_for_timeout(50)
    page.screenshot(path="shots/target.png", full_page=True)

    # home after edits
    page.locator("button[data-act=tab][data-id=home]").click()
    page.wait_for_selector(".hero")
    check("pace line mentions days left", "day" in page.inner_text(".pace") and "5,000" in page.inner_text(".yearhead"))
    page.screenshot(path="shots/home_after.png", full_page=True)
    check("no JS errors through whole flow", not errors, errors)
    ctx.close()

    # ---------- 2. corrupted storage + v1 migration + malformed import ----------
    ctx = browser.new_context(**IPHONE)
    page = ctx.new_page()
    errs2 = []
    page.on("pageerror", lambda e: errs2.append(str(e)))
    page.goto(URL); page.wait_for_selector(".hero")
    page.evaluate("localStorage.setItem('level.v2', '{not json')")
    page.reload(); page.wait_for_selector(".hero")
    check("corrupted storage falls back to seed without crashing", not errs2 and page.inner_text(".total").strip() == "0")
    check("corrupted blob preserved for recovery", page.evaluate("localStorage.getItem('level.broken')") == "{not json")
    v1 = {"habits":[{"id":"h1","name":"Gym","xp":50,"mode":"multi"}],
          "goals":[{"id":"g1","name":"Goal","xp":300,"done":True}],
          "log":[{"id":"a","habitId":"h1","name":"Gym","xp":50,"date":"2026-09-01","at":1},
                 {"id":"goal-g1","goalId":"g1","name":"Goal","xp":300,"date":"2026-09-02","at":2},
                 {"id":"bad","habitId":"h1","name":"Gym","xp":50,"date":"2026-02-31","at":3}],
          "target":10000,"deadline":"2026-12-31","start":"2026-09-01"}
    page.evaluate("localStorage.removeItem('level.v2')")
    page.evaluate("v => localStorage.setItem('level.v1', JSON.stringify(v))", v1)
    page.reload(); page.wait_for_selector(".hero")
    d = json.loads(page.evaluate("localStorage.getItem('level.v2')"))
    check("v1 data migrates (habitId/goalId -> type/refId)", d["log"][0]["type"] == "habit" and d["log"][1]["type"] == "goal")
    check("invalid date 2026-02-31 dropped on migration", len(d["log"]) == 2)
    check("migrated habit assigned to a real section", d["habits"][0]["cat"] in {c["id"] for c in d["cats"]})
    check("migrated total is 350", page.inner_text(".total").strip() == "350")
    check("no errors during migration", not errs2, errs2)

    # goal.done inconsistent with log gets corrected
    page.evaluate("""() => { const s=JSON.parse(localStorage.getItem('level.v2'));
      s.goals.push({id:'gx',name:'Ghost',xp:999,cat:s.cats[0].id,done:true,doneDate:'2026-09-01'});
      localStorage.setItem('level.v2', JSON.stringify(s)); }""")
    page.reload(); page.wait_for_selector(".hero")
    d = json.loads(page.evaluate("localStorage.getItem('level.v2')"))
    ghost = [g for g in d["goals"] if g["id"] == "gx"][0]
    check("done flag without a log entry is reset to open", ghost["done"] is False and ghost["doneDate"] is None)

    page.evaluate("""() => { const s=JSON.parse(localStorage.getItem('level.v2'));
      s.tasks=[{id:'t1',name:'ok',xp:5,cat:'nope',date:'2026-09-01',done:true},{id:'t2',name:'bad date',xp:5,date:'2026-13-01'},null];
      s.reminders={times:['25:00','9:00','15:00','15:00'],badge:'yes'};
      localStorage.setItem('level.v2', JSON.stringify(s)); }""")
    page.reload(); page.wait_for_selector(".hero")
    d = json.loads(page.evaluate("localStorage.getItem('level.v2')"))
    check("bad tasks dropped, orphan section repaired, done-without-log reset", len(d["tasks"]) == 1 and d["tasks"][0]["cat"] in {c["id"] for c in d["cats"]} and d["tasks"][0]["done"] is False)
    check("invalid reminder times dropped and deduplicated", d["reminders"]["times"] == ["15:00"] and d["reminders"]["badge"] is True)

    # XSS-ish names render as text, not markup
    page.evaluate("""() => { const s=JSON.parse(localStorage.getItem('level.v2'));
      s.habits.push({id:'x',name:'<img src=x onerror=alert(1)> & "quotes"',xp:5,mode:'daily',cat:s.cats[0].id});
      localStorage.setItem('level.v2', JSON.stringify(s)); }""")
    page.reload(); page.wait_for_selector(".hero")
    check("html in names is escaped", page.locator("img[src=x]").count() == 0 and '<img' in page.locator(".row", has_text="quotes").inner_text())
    ctx.close()

    # ---------- 3. DST boundary: Sun 25 Oct 2026, clocks go back in Rome ----------
    ctx = browser.new_context(**IPHONE)
    page = ctx.new_page()
    page.clock.install(time=datetime.datetime(2026, 10, 24, 23, 55, 0, tzinfo=ROME))
    page.goto(URL); page.wait_for_selector(".hero")
    page.locator(".row[data-act=log]", has_text="Gym session").click(); page.wait_for_timeout(50)
    page.clock.run_for(10 * 60 * 1000)   # -> 00:05 on 25 Oct
    page.evaluate("document.dispatchEvent(new Event('visibilitychange'))"); page.wait_for_timeout(80)
    page.locator(".row[data-act=log]", has_text="Gym session").click(); page.wait_for_timeout(50)
    page.clock.run_for(26 * 60 * 60 * 1000)  # through the DST change to 26 Oct ~01:05 (25h day)
    page.evaluate("document.dispatchEvent(new Event('visibilitychange'))"); page.wait_for_timeout(80)
    page.locator(".row[data-act=log]", has_text="Gym session").click(); page.wait_for_timeout(50)
    d = json.loads(page.evaluate("localStorage.getItem('level.v2')"))
    dates = sorted(e["date"] for e in d["log"])
    check("entries across the DST change land on 24, 25, 26 Oct", dates == ["2026-10-24", "2026-10-25", "2026-10-26"], dates)
    check("streak counts 3 across DST", "3 day streak" in page.inner_text(".streak"), page.inner_text(".streak"))
    page.locator("button[data-act=tab][data-id=calendar]").click(); page.wait_for_selector(".cal")
    check("calendar moved to October after rollover", "October 2026" in page.inner_text(".calhead"))
    check("Oct 1 2026 is a Thursday -> 3 blanks", all("blank" in c.get_attribute("class") for c in page.locator(".cal .day").all()[:3]) and page.locator(".cal .day").all()[3].inner_text().startswith("1"))
    ctx.close()

    # ---------- 3b. weekly habits: Sat 12 Sep 2026, mid-week pressure ----------
    # Sat 12 Sep 2026 sits in the week starting Mon 7 Sep. Two days are left,
    # so a fresh "3x a week" habit is already unmissable.
    ctx = browser.new_context(**IPHONE)
    page = ctx.new_page()
    werr = []
    page.on("pageerror", lambda e: werr.append(str(e)))
    page.clock.install(time=datetime.datetime(2026, 9, 12, 10, 0, 0, tzinfo=ROME))
    page.on("dialog", lambda dlg: dlg.accept())
    page.goto(URL); page.wait_for_selector(".hero")

    page.locator("button[data-act=tab][data-id=manage]").click()
    page.locator("button[data-act=seg][data-id=habits]").click()
    check("weekly fields hidden until 'Times a week' is picked",
          "hidden" in page.locator("#f-h-weekly").get_attribute("class"))
    page.fill("#f-h-name", "Weekly gym")
    page.fill("#f-h-xp", "50")
    page.select_option("#f-h-mode", "weekly")
    check("picking 'Times a week' reveals the count and bonus fields",
          "hidden" not in page.locator("#f-h-weekly").get_attribute("class"))
    check("switching mode keeps what was already typed", page.input_value("#f-h-name") == "Weekly gym")
    page.fill("#f-h-per", "3")
    page.fill("#f-h-bonus", "60")
    page.locator("button[data-act=save-habit]").click(); page.wait_for_timeout(60)
    check("weekly habit listed with its count and bonus",
          "3× a week, +60 bonus" in page.locator(".row", has_text="Weekly gym").inner_text(),
          page.locator(".row", has_text="Weekly gym").inner_text())

    page.locator("button[data-act=tab][data-id=home]").click(); page.wait_for_timeout(60)
    gym = lambda: page.locator(".row[data-act=log]", has_text="Weekly gym")
    check("starts at 0 of 3", "0 of 3 this week" in gym().inner_text(), gym().inner_text())
    check("3 pips, none filled", gym().locator(".pips i").count() == 3
          and not any(i.get_attribute("style") for i in gym().locator(".pips i").all()))
    check("Saturday with 3 still to go says go today", "go today" in gym().inner_text(), gym().inner_text())

    gym().click(); page.wait_for_timeout(60)
    check("one session logged: 2 to go", "1 of 3 this week" in gym().inner_text() and "2 left, go today" in gym().inner_text(), gym().inner_text())
    check("first pip filled", sum(1 for i in gym().locator(".pips i").all() if i.get_attribute("style")) == 1)
    gym().click(); page.wait_for_timeout(60)
    check("two sessions logged: 1 to go", "2 of 3 this week" in gym().inner_text(), gym().inner_text())
    check("XP is the sessions only, no bonus yet", page.inner_text(".total").strip() == "100", page.inner_text(".total"))
    gym().click(); page.wait_for_timeout(60)
    check("third session completes the week", "3 of 3 this week" in gym().inner_text() and "done, +60 bonus" in gym().inner_text(), gym().inner_text())
    check("bonus paid on top of the three sessions", page.inner_text(".total").strip() == "210", page.inner_text(".total"))
    check("bonus toast shown", "bonus +60 XP" in page.inner_text("#toast"), page.inner_text("#toast"))
    page.screenshot(path="shots/weekly_done.png", full_page=True)

    d = json.loads(page.evaluate("localStorage.getItem('level.v2')"))
    bonuses = [e for e in d["log"] if e["type"] == "bonus"]
    check("exactly one bonus entry, dated to the session that finished the week",
          len(bonuses) == 1 and bonuses[0]["date"] == "2026-09-12" and bonuses[0]["xp"] == 60, bonuses)
    check("total XP is still just the sum of the log", sum(e["xp"] for e in d["log"]) == 210)

    # a fourth session in the same week pays its XP but not a second bonus
    gym().click(); page.wait_for_timeout(60)
    d = json.loads(page.evaluate("localStorage.getItem('level.v2')"))
    check("extra session pays no second bonus",
          len([e for e in d["log"] if e["type"] == "bonus"]) == 1 and page.inner_text(".total").strip() == "260")
    check("row counts the extra session", "4 this week" in gym().inner_text(), gym().inner_text())

    # the calendar shows the bonus as its own entry, and will not let you remove it
    page.locator("button[data-act=tab][data-id=calendar]").click(); page.wait_for_selector(".cal")
    bonus_entry = page.locator(".entry", has_text="in a week")
    check("bonus appears in the day's entries, tagged", bonus_entry.count() == 1 and "weekly bonus" in bonus_entry.inner_text())
    check("bonus has no Remove button of its own", bonus_entry.locator("button[data-act=rm-entry]").count() == 0)
    page.locator("button[data-act=tab][data-id=home]").click(); page.wait_for_timeout(60)

    # undo steps over the bonus; dropping under the count takes the bonus back
    page.locator("button[data-act=undo]").click(); page.wait_for_timeout(60)
    d = json.loads(page.evaluate("localStorage.getItem('level.v2')"))
    check("undo removes a session, not the bonus",
          len([e for e in d["log"] if e["type"] == "bonus"]) == 1 and page.inner_text(".total").strip() == "210")
    page.locator("button[data-act=undo]").click(); page.wait_for_timeout(60)
    d = json.loads(page.evaluate("localStorage.getItem('level.v2')"))
    check("falling under the count takes the bonus back",
          not [e for e in d["log"] if e["type"] == "bonus"] and page.inner_text(".total").strip() == "100", page.inner_text(".total"))
    check("row reverts to 2 of 3", "2 of 3 this week" in gym().inner_text(), gym().inner_text())
    gym().click(); page.wait_for_timeout(60)
    check("re-earning pays the bonus exactly once again", page.inner_text(".total").strip() == "210")

    # ---------- the week rolls over on Monday ----------
    page.clock.run_for(2 * 24 * 60 * 60 * 1000)   # Sat 12 -> Mon 14 Sep
    page.evaluate("document.dispatchEvent(new Event('visibilitychange'))"); page.wait_for_timeout(120)
    check("header moved to Monday 14 September", "Monday 14 September" in page.inner_text("#today"), page.inner_text("#today"))
    check("weekly counter resets on Monday", "0 of 3 this week" in gym().inner_text(), gym().inner_text())
    check("Monday with a full week ahead does not nag", "go today" not in gym().inner_text(), gym().inner_text())
    check("last week's XP and bonus are untouched", page.inner_text(".total").strip() == "210")

    # raising the count must not strip a bonus already earned in an earlier week
    page.locator("button[data-act=tab][data-id=manage]").click()
    page.locator("button[data-act=seg][data-id=habits]").click()
    page.locator(".row", has_text="Weekly gym").locator("button[data-act=edit-habit]").click(); page.wait_for_timeout(60)
    check("edit form prefilled with the weekly settings",
          page.input_value("#f-h-per") == "3" and page.input_value("#f-h-bonus") == "60")
    page.fill("#f-h-per", "4")
    page.locator("button[data-act=save-habit]").click(); page.wait_for_timeout(60)
    d = json.loads(page.evaluate("localStorage.getItem('level.v2')"))
    check("raising 3x to 4x leaves last week's bonus alone",
          len([e for e in d["log"] if e["type"] == "bonus"]) == 1 and sum(e["xp"] for e in d["log"]) == 210, d["log"])
    check("weekly settings survive a save", d["habits"][-1]["perWeek"] == 4 and d["habits"][-1]["bonus"] == 60)

    # switching a weekly habit to once-a-day collapses that day and drops the live bonus
    page.locator(".row", has_text="Weekly gym").locator("button[data-act=edit-habit]").click(); page.wait_for_timeout(60)
    page.select_option("#f-h-mode", "daily")
    page.locator("button[data-act=save-habit]").click(); page.wait_for_timeout(60)
    d = json.loads(page.evaluate("localStorage.getItem('level.v2')"))
    sess = [e for e in d["log"] if e["type"] == "habit" and e["name"] == "Weekly gym"]
    check("weekly -> once a day collapses the repeated day to one entry", len(sess) == 1, sess)
    check("no JS errors anywhere in the weekly flow", not werr, werr)
    ctx.close()

    # ---------- 3c. fixes: section delete, badge count, reset wording ----------
    ctx = browser.new_context(**IPHONE)
    page = ctx.new_page()
    page.clock.install(time=datetime.datetime(2026, 9, 8, 9, 0, 0, tzinfo=ROME))
    page.on("dialog", lambda dlg: dlg.accept())
    page.goto(URL); page.wait_for_selector(".hero")
    # a daily goal in School, then delete the School section
    page.locator("button[data-act=task-form]").click(); page.wait_for_timeout(50)
    page.fill("#f-t-name", "Homework"); page.fill("#f-t-xp", "40")
    page.select_option("#f-t-cat", label="School")
    page.locator("button[data-act=task-add]").click(); page.wait_for_timeout(60)
    page.locator("button[data-act=tab][data-id=manage]").click(); page.wait_for_selector(".seg")
    page.locator(".row", has_text="School").locator("button[data-act=del-cat]").click(); page.wait_for_timeout(80)
    d = json.loads(page.evaluate("localStorage.getItem('level.v2')"))
    cat_ids = {c["id"] for c in d["cats"]}
    check("deleting a section moves its daily goals too, no orphans",
          all(t["cat"] in cat_ids for t in d["tasks"]), [t["cat"] for t in d["tasks"]])
    check("lastTaskCat is not left pointing at the deleted section", d["lastTaskCat"] in cat_ids)

    # badge counts goals carried over from earlier days, not just today's
    page.evaluate("""() => { window.__badge=[]; navigator.setAppBadge = n => { window.__badge.push(n); return Promise.resolve(); };
                            navigator.clearAppBadge = () => { window.__badge.push(0); return Promise.resolve(); }; }""")
    page.clock.run_for(24 * 60 * 60 * 1000)   # -> 9 Sep, yesterday's goal is now overdue
    page.evaluate("document.dispatchEvent(new Event('visibilitychange'))"); page.wait_for_timeout(120)
    page.locator("button[data-act=tab][data-id=home]").click(); page.wait_for_timeout(80)
    overdue = page.locator(".row.task", has_text="Homework").count()
    calls = page.evaluate("window.__badge")
    check("badge and 'left' count include unfinished goals from earlier days",
          overdue == 1 and calls and calls[-1] == 5, (overdue, calls, page.inner_text(".pendline")))
    ctx.close()

    # ---------- 3d. dark mode ----------
    ctx = browser.new_context(color_scheme="dark", **IPHONE)
    page = ctx.new_page()
    derr = []
    page.on("pageerror", lambda e: derr.append(str(e)))
    page.clock.install(time=datetime.datetime(2026, 9, 8, 22, 0, 0, tzinfo=ROME))
    page.goto(URL); page.wait_for_selector(".hero")
    check("a dark phone gets the dark theme", page.evaluate("document.documentElement.getAttribute('data-theme')") == "dark")
    check("page background is the dark token",
          page.evaluate("getComputedStyle(document.body).backgroundColor") == "rgb(11, 18, 32)",
          page.evaluate("getComputedStyle(document.body).backgroundColor"))
    check("status bar colour follows the theme", page.get_attribute("#tc", "content") == "#0B1220")
    check("color-scheme is set so native controls follow",
          page.evaluate("getComputedStyle(document.documentElement).colorScheme") == "dark")

    # every painted surface must come from a token: nothing may stay pure white
    whites = []
    for t in ("home", "calendar", "manage"):
        page.locator("button[data-act=tab][data-id=%s]" % t).click(); page.wait_for_timeout(80)
        whites += page.evaluate("""() => [...document.querySelectorAll('#view *, .tabs, .tabs *, .toast')]
            .filter(e => !e.closest('.hero'))   // the hero bar is white on its blue gradient, by design
            .filter(e => getComputedStyle(e).backgroundColor === 'rgb(255, 255, 255)')
            .map(e => e.tagName + '.' + (e.className || '')).slice(0, 8)""")
    page.locator("button[data-act=tab][data-id=manage]").click()
    for s in ("cats", "habits", "goals", "target"):
        page.locator("button[data-act=seg][data-id=%s]" % s).click(); page.wait_for_timeout(80)
        whites += page.evaluate("""() => [...document.querySelectorAll('#view *')]
            .filter(e => !e.closest('.hero'))   // the hero bar is white on its blue gradient, by design
            .filter(e => getComputedStyle(e).backgroundColor === 'rgb(255, 255, 255)')
            .map(e => e.tagName + '.' + (e.className || '')).slice(0, 8)""")
    check("no surface is left hardcoded white in dark mode", not whites, whites)
    page.screenshot(path="shots/dark_manage.png", full_page=True)

    # forcing a theme overrides the phone, and survives a reload without flashing
    page.locator("button[data-act=seg][data-id=target]").click(); page.wait_for_timeout(60)
    page.locator("button[data-act=theme][data-id=light]").click(); page.wait_for_timeout(60)
    check("forcing light overrides a dark phone",
          page.evaluate("document.documentElement.getAttribute('data-theme')") == "light"
          and page.get_attribute("#tc", "content") == "#F3F5F9")
    page.reload(); page.wait_for_selector(".hero")
    check("the head script applies the forced theme before the first paint",
          page.evaluate("document.documentElement.getAttribute('data-theme')") == "light")
    page.locator("button[data-act=tab][data-id=manage]").click()
    page.locator("button[data-act=seg][data-id=target]").click(); page.wait_for_timeout(60)
    page.locator("button[data-act=theme][data-id=auto]").click(); page.wait_for_timeout(60)
    check("back on auto it follows the phone again",
          page.evaluate("document.documentElement.getAttribute('data-theme')") == "dark")
    check("no JS errors in dark mode", not derr, derr)
    ctx.close()

    # a light phone is unaffected
    ctx = browser.new_context(color_scheme="light", **IPHONE)
    page = ctx.new_page()
    page.goto(URL); page.wait_for_selector(".hero")
    check("a light phone still gets the light theme",
          page.evaluate("document.documentElement.getAttribute('data-theme')") == "light"
          and page.evaluate("getComputedStyle(document.body).backgroundColor") == "rgb(243, 245, 249)")
    ctx.close()

    # ---------- 3e. backup nudge ----------
    ctx = browser.new_context(accept_downloads=True, **IPHONE)
    page = ctx.new_page()
    page.clock.install(time=datetime.datetime(2026, 9, 8, 9, 0, 0, tzinfo=ROME))
    page.on("dialog", lambda dlg: dlg.accept())
    page.goto(URL); page.wait_for_selector(".hero")
    check("a fresh install does not nag about backups", page.locator(".remind.backup").count() == 0)
    page.locator(".row[data-act=log]", has_text="8k steps").click(); page.wait_for_timeout(60)
    check("nor does it after one day of use", page.locator(".remind.backup").count() == 0)

    # wind the clock back by moving `start`, which is what the nudge counts from
    page.evaluate("""() => { const s = JSON.parse(localStorage.getItem('level.v2'));
        s.start = '2026-08-19'; s.lastBackup = null;
        localStorage.setItem('level.v2', JSON.stringify(s)); }""")
    page.reload(); page.wait_for_selector(".hero")
    check("after 20 days with no backup, Home says so",
          page.locator(".remind.backup").count() == 1
          and "20 days of entries" in page.locator(".remind.backup").inner_text(),
          page.locator(".remind.backup").inner_text() if page.locator(".remind.backup").count() else "no nudge")
    page.screenshot(path="shots/backup_nudge.png", full_page=True)

    with page.expect_download() as dl:
        page.locator(".remind.backup button[data-act=export]").click()
    check("the nudge's button exports a dated backup file",
          dl.value.suggested_filename == "level-backup-2026-09-08.json", dl.value.suggested_filename)
    page.wait_for_timeout(120)
    d = json.loads(page.evaluate("localStorage.getItem('level.v2')"))
    check("exporting records the backup date", d["lastBackup"] == "2026-09-08", d.get("lastBackup"))
    check("the nudge goes away once backed up", page.locator(".remind.backup").count() == 0)
    page.locator("button[data-act=tab][data-id=manage]").click()
    page.locator("button[data-act=seg][data-id=target]").click(); page.wait_for_timeout(60)
    check("settings shows when the last backup was", "Last backup 8 Sept 2026" in page.inner_text("#view"), page.inner_text("#view")[:200])

    # it comes back when the backup goes stale
    page.evaluate("""() => { const s = JSON.parse(localStorage.getItem('level.v2'));
        s.lastBackup = '2026-08-20';
        localStorage.setItem('level.v2', JSON.stringify(s)); }""")
    page.reload(); page.wait_for_selector(".hero")
    check("a stale backup brings the nudge back",
          page.locator(".remind.backup").count() == 1
          and "Last backup 19 days ago" in page.locator(".remind.backup").inner_text(),
          page.locator(".remind.backup").inner_text() if page.locator(".remind.backup").count() else "no nudge")
    ctx.close()

    # ---------- 3f. weight tracking ----------
    ctx = browser.new_context(**IPHONE)
    page = ctx.new_page()
    werr2 = []
    page.on("pageerror", lambda e: werr2.append(str(e)))
    page.clock.install(time=datetime.datetime(2026, 9, 10, 8, 0, 0, tzinfo=ROME))  # Thursday
    page.on("dialog", lambda dlg: dlg.accept())
    page.goto(URL); page.wait_for_selector(".hero")

    check("weight card on home with a log field", page.locator(".wcard #f-wt").count() == 1)
    # goal set inline on first use, with a comma decimal like the Italian keypad types
    page.fill("#f-w-goal-h", "70")
    page.locator("button[data-act=wt-goal-home]").click(); page.wait_for_timeout(60)
    d = json.loads(page.evaluate("localStorage.getItem('level.v2')"))
    check("inline goal saved and its row gone", d["weight"]["goal"] == 70 and page.locator("#f-w-goal-h").count() == 0)

    page.fill("#f-wt", "72,6")
    page.locator("button[data-act=wt-log]").click(); page.wait_for_timeout(60)
    d = json.loads(page.evaluate("localStorage.getItem('level.v2')"))
    check("comma decimal logged as 72.6", d["weight"]["entries"] == [{"date": "2026-09-10", "kg": 72.6}], d["weight"]["entries"])
    check("button flips to Update", "Update" in page.locator("button[data-act=wt-log]").inner_text())
    page.fill("#f-wt", "72.4")
    page.locator("button[data-act=wt-log]").click(); page.wait_for_timeout(60)
    d = json.loads(page.evaluate("localStorage.getItem('level.v2')"))
    check("logging the same day again corrects it, one entry only",
          d["weight"]["entries"] == [{"date": "2026-09-10", "kg": 72.4}], d["weight"]["entries"])
    check("weight never touches XP", page.inner_text(".total").strip() == "0" and d["log"] == [])
    for bad in ("7,2", "500", "abc"):
        page.fill("#f-wt", bad)
        page.locator("button[data-act=wt-log]").click(); page.wait_for_timeout(50)
    d = json.loads(page.evaluate("localStorage.getItem('level.v2')"))
    check("nonsense weights rejected", len(d["weight"]["entries"]) == 1 and d["weight"]["entries"][0]["kg"] == 72.4)

    # two settled weeks of history + this week: averages, line, goal line, hollow point
    page.evaluate("""() => { const s = JSON.parse(localStorage.getItem('level.v2'));
        s.weight.entries = [
          {date:'2026-08-24',kg:73.4},{date:'2026-08-26',kg:73.0},{date:'2026-08-28',kg:73.2}, // avg 73.2
          {date:'2026-08-31',kg:73.0},{date:'2026-09-02',kg:72.6},{date:'2026-09-04',kg:72.8}, // avg 72.8
          {date:'2026-09-07',kg:72.2},{date:'2026-09-08',kg:72.6},{date:'2026-09-10',kg:72.1}  // this week: avg 72.3
        ];
        localStorage.setItem('level.v2', JSON.stringify(s)); }""")
    page.reload(); page.wait_for_selector(".hero")
    meta = page.locator(".wmeta").inner_text()
    check("weekly average shown for the running week", "72.3 kg" in meta and "3 mornings so far" in meta, meta)
    check("change against last week's average", "0.5 kg vs last week" in meta, meta)
    check("distance to goal", "2.3 kg above goal" in meta, meta)
    svg = page.locator(".wchart svg")
    check("one point per week", svg.locator("circle").count() == 3)
    check("running week's point is hollow", svg.locator("circle[stroke-width='2']").count() == 1)
    check("weekly points joined by a line", svg.locator("polyline").count() == 1)
    check("goal drawn as a labelled dashed line",
          svg.locator("line[stroke-dasharray='5 4']").count() == 1 and "Goal 70.0" in svg.inner_text())
    check("segment into the running week is dashed", svg.locator("line[stroke-dasharray='4 4']").count() == 1)
    page.screenshot(path="shots/weight_chart.png", full_page=True)

    # calendar: fix yesterday, remove it, and no weight form on a future day
    page.locator("button[data-act=tab][data-id=calendar]").click(); page.wait_for_selector(".cal")
    page.locator(".cal .day", has_text="9").first.click(); page.wait_for_timeout(60)
    page.fill("#f-wt-day", "71.9")
    page.locator("button[data-act=wt-log-day]").click(); page.wait_for_timeout(60)
    d = json.loads(page.evaluate("localStorage.getItem('level.v2')"))
    check("a past day's weight can be added from the calendar",
          {"date": "2026-09-09", "kg": 71.9} in d["weight"]["entries"], d["weight"]["entries"])
    page.locator("button[data-act=wt-del-day]").click(); page.wait_for_timeout(60)
    d = json.loads(page.evaluate("localStorage.getItem('level.v2')"))
    check("and removed again", not [e for e in d["weight"]["entries"] if e["date"] == "2026-09-09"])
    page.locator(".cal .day", has_text="25").first.click(); page.wait_for_timeout(60)
    check("no weight form on a future day", page.locator("#f-wt-day").count() == 0)

    # a corrupted backup keeps the sane entries and drops the junk
    page.evaluate("""() => { const s = JSON.parse(localStorage.getItem('level.v2'));
        s.weight.goal = 'seventy';
        s.weight.entries.push({date:'2026-09-01',kg:9999},{date:'not-a-date',kg:72},{date:'2026-09-03'},
                              {date:'2026-09-02',kg:72.0},{date:'2026-09-02',kg:71.0});
        localStorage.setItem('level.v2', JSON.stringify(s)); }""")
    page.reload(); page.wait_for_selector(".hero")
    d = json.loads(page.evaluate("localStorage.getItem('level.v2')"))
    days = [e["date"] for e in d["weight"]["entries"]]
    check("normalise drops junk weights, keeps one entry per day",
          d["weight"]["goal"] is None and len(days) == len(set(days))
          and all(20 <= e["kg"] <= 300 for e in d["weight"]["entries"]), d["weight"])
    check("no JS errors in the weight flow", not werr2, werr2)
    ctx.close()

    # ---------- 4. desktop width sanity + manifest/sw reachable ----------
    ctx = browser.new_context(viewport={"width": 1280, "height": 900})
    page = ctx.new_page()
    page.goto(URL); page.wait_for_selector(".hero")
    w = page.evaluate("document.querySelector('.app').getBoundingClientRect().width")
    check("content capped at 480px on desktop", 470 <= w <= 481, w)
    r = page.request.get("http://localhost:8765/manifest.json")
    check("manifest reachable and valid", r.ok and r.json()["display"] == "standalone")
    r = page.request.get("http://localhost:8765/sw.js")
    check("service worker file reachable", r.ok)
    page.wait_for_timeout(600)
    sw = page.evaluate("navigator.serviceWorker.getRegistrations().then(r => r.length)")
    check("service worker registers", sw >= 1, sw)
    ctx.close()
    browser.close()

server.terminate()
print("\n%d failures" % len(fails))
for f in fails: print(" -", f)
sys.exit(1 if fails else 0)
